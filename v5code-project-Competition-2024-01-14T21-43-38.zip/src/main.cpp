/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
}

void autonomous(void) {
  // Phase 1
  inertial DrivetrainInertial = inertial(PORT5);
  digital_out PneuRight = digital_out(Brain.ThreeWirePort.A);
  digital_out PneuLeft = digital_out(Brain.ThreeWirePort.B);
  DrivetrainInertial.setHeading(245,degrees);
  PneuRight = true;
  PneuLeft = true;
  Drivetrain.driveFor(forward,24,inches);
  // Phase 2
  Drivetrain.turnToHeading(270,degrees);
  Drivetrain.driveFor(forward,24,inches);
  Drivetrain.driveFor(reverse,6,inches);
  Drivetrain.driveFor(forward,6,inches);
  // Phase 3
  PneuRight = false;
  PneuLeft = false;
  Drivetrain.driveFor(reverse,6,inches);
  Drivetrain.turnToHeading(45,degrees);
  Drivetrain.driveFor(forward,48,inches);
  PneuRight = true;
  PneuLeft = true;
  Drivetrain.turnToHeading(0,degrees);
  Drivetrain.driveFor(forward,72,inches);
}

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    wait(20, msec);
  }
}

int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
