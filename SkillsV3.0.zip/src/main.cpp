/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// Drivetrain           drivetrain    1, 10, 11, 20, 4
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
vex::timer timer;

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
 
  
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  motor leftMotorA = motor(PORT1, ratio6_1, true);
  motor leftMotorB = motor(PORT8, ratio6_1, true);
  motor leftMotorC = motor(PORT9, ratio6_1, true);
  motor_group LeftDriveSmart = motor_group(leftMotorA, leftMotorB, leftMotorC);
  motor rightMotorA = motor(PORT11, ratio6_1, false);
  motor rightMotorB = motor(PORT18, ratio6_1, false);
  motor rightMotorC = motor(PORT19, ratio6_1, false);
  motor_group RightDriveSmart = motor_group(rightMotorA, rightMotorB, rightMotorC);
  motor intakeMotorA = motor(PORT10, ratio18_1, false);
  motor intakeMotorB = motor(PORT20, ratio18_1, true);
  motor_group Intake = motor_group(intakeMotorA, intakeMotorB);
  inertial DrivetrainInertial = inertial(PORT21);
  smartdrive Drivetrain = smartdrive(LeftDriveSmart, RightDriveSmart, DrivetrainInertial, 299.24, 320, 40, mm, 0.6);
  digital_out pneuLeft = digital_out(Brain.ThreeWirePort.A);
  digital_out pneuRight = digital_out(Brain.ThreeWirePort.H);
  distance DistSensor = distance(PORT2);
  motor ScorpioMotorA = motor(PORT6, ratio36_1, false);
  motor ScorpioMotorB = motor(PORT16, ratio36_1, true);
  motor_group Scorpio = motor_group(ScorpioMotorA, ScorpioMotorB);
  Scorpio.setVelocity(100, percent);
  Scorpio.setMaxTorque(100, percent);
  Drivetrain.setDriveVelocity(45,percent);
  Drivetrain.setTurnVelocity(2,percent);
  Drivetrain.setHeading(60, degrees);
  Intake.setVelocity(100,percent);
  Intake.setMaxTorque(100,percent);
  int NumTriballs = 0;
  // phase 1
  Brain.Timer.reset();
  while (NumTriballs < 43 && Brain.Timer < 35000) {
    if(DistSensor.objectDistance(inches) < 1.5){
      Scorpio.spinFor(forward, 1.5, turns);
      NumTriballs += 1;
    }
    wait(20, msec); 
  }
  //Phase 2
  RightDriveSmart.spinFor(reverse, 0.58, turns, false);
  LeftDriveSmart.spinFor(forward, 0.58, turns);
  Drivetrain.driveFor(forward, 2, inches);
  Drivetrain.turnToHeading(97.5, degrees);
  Drivetrain.driveFor(forward, 92, inches);
  Drivetrain.setDriveVelocity(35,percent);
  RightDriveSmart.spinFor(forward, 0.8, turns);
  Drivetrain.driveFor(forward, 27, inches);
  RightDriveSmart.spinFor(forward, 1.5, turns);
  Drivetrain.turnToHeading(0, degrees);
  //Phase 3
  Intake.spin(reverse);
  Drivetrain.setDriveVelocity(75,percent);
  Drivetrain.driveFor(forward, 13, inches);
  Drivetrain.setDriveVelocity(35,percent);
  Drivetrain.driveFor(reverse, 13, inches);
  Drivetrain.setDriveVelocity(75,percent);
  Drivetrain.driveFor(forward, 13, inches);
  Drivetrain.setDriveVelocity(35,percent);
  Drivetrain.driveFor(reverse, 2, inches);
  Intake.stop();
  //Phase 4
  RightDriveSmart.spinFor(reverse, 1.8, turns, false);
  LeftDriveSmart.spinFor(forward, 1.8, turns);
  Drivetrain.turnToHeading(100, degrees);
  Drivetrain.driveFor(reverse, 55, inches);
  RightDriveSmart.spinFor(reverse, 1.8, turns, false);
  LeftDriveSmart.spinFor(forward, 1.8, turns);
  Drivetrain.turnToHeading(180, degrees);
  Drivetrain.driveFor(reverse, 5, inches);
  pneuLeft = true;
  pneuRight = true;
  Drivetrain.driveFor(reverse, 12.5, inches);
  RightDriveSmart.spinFor(reverse, 3.5, turns);
  Drivetrain.turnToHeading(270, degrees);
  Drivetrain.setDriveVelocity(60,percent);
  Drivetrain.setTimeout(2, seconds);
  Drivetrain.driveFor(reverse, 33, inches);
  Drivetrain.setDriveVelocity(30,percent);
  Drivetrain.turnToHeading(270, degrees);
  Drivetrain.driveFor(forward, 3, inches);
  pneuLeft = false;
  pneuRight = false;
  Drivetrain.driveFor(forward, 27, inches);
  RightDriveSmart.spinFor(forward, 3, turns);
  Drivetrain.turnToHeading(180, degrees);
  Drivetrain.driveFor(reverse, 15, inches);
  RightDriveSmart.spinFor(reverse, 3, turns);
  pneuLeft = true;
  pneuRight = true;
  Drivetrain.turnToHeading(270, degrees);
  Drivetrain.setDriveVelocity(60,percent);
  Drivetrain.setTimeout(2, seconds);
  Drivetrain.driveFor(reverse, 33, inches);
  Drivetrain.setDriveVelocity(30,percent);
  Drivetrain.turnToHeading(270, degrees);
  Drivetrain.driveFor(forward, 3, inches);
  pneuLeft = false;
  pneuRight = false;
  Drivetrain.driveFor(forward, 15, inches);
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  digital_out pneuLeft = digital_out(Brain.ThreeWirePort.A);
  digital_out pneuRight = digital_out(Brain.ThreeWirePort.H);
  distance DistSensor = distance(PORT2);
  motor ScorpioMotorA = motor(PORT6, ratio36_1, false);
  motor ScorpioMotorB = motor(PORT16, ratio36_1, true);
  motor_group Scorpio = motor_group(ScorpioMotorA, ScorpioMotorB);
  motor intakeMotorA = motor(PORT10, ratio18_1, false);
  motor intakeMotorB = motor(PORT20, ratio18_1, true);
  motor_group Intake = motor_group(intakeMotorA, intakeMotorB);
  pneuLeft = false;
  pneuRight = false;
  bool launcherToggle = true;
  Scorpio.setVelocity(100, percent);
  Scorpio.setMaxTorque(100, percent);
  // User control code here, inside the loop
  while (1) {
    if (Controller1.ButtonB.pressing()) {
      if (launcherToggle) {
        launcherToggle = false;
        launcherToggle = false;
      } else {
        launcherToggle = true;
        launcherToggle = true;
      }
      waitUntil(!Controller1.ButtonB.pressing());
    }
    if(DistSensor.objectDistance(inches) < 1.5 && launcherToggle){
      Scorpio.spinFor(forward, 1.5, turns);
    }
    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
    // intake control
    if (Controller1.ButtonR2.pressing()) {
      Intake.setVelocity(100,percent);
      Intake.setMaxTorque(100,percent);
      Intake.spin(forward);
    } else if (Controller1.ButtonR1.pressing()) {
      Intake.setVelocity(100,percent);
      Intake.setMaxTorque(100,percent);
      Intake.spin(reverse);
    } else {
      Intake.stop();
    }
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
