/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
}

void autonomous(void) {
  // Phase 1
  inertial DrivetrainInertial = inertial(PORT5);
  digital_out PneuRight = digital_out(Brain.ThreeWirePort.A);
  digital_out PneuLeft = digital_out(Brain.ThreeWirePort.B);
  motor leftMotorA = motor(PORT19, ratio6_1, true);
  motor leftMotorB = motor(PORT20, ratio6_1, true);
  motor leftMotorC = motor(PORT10, ratio6_1, true);
  motor_group LeftDriveSmart = motor_group(leftMotorA, leftMotorB, leftMotorC);
  motor rightMotorA = motor(PORT11, ratio6_1, false);
  motor rightMotorB = motor(PORT12, ratio6_1, false);
  motor rightMotorC = motor(PORT1, ratio6_1, false);
  motor_group RightDriveSmart = motor_group(rightMotorA, rightMotorB, rightMotorC);
  DrivetrainInertial.setHeading(330,degrees);
  Drivetrain.setTurnVelocity(40, percent);
  Drivetrain.setDriveVelocity(35, percent);
  LeftDriveSmart.setVelocity(70, percent);
  LeftDriveSmart.setMaxTorque(100, percent);
  RightDriveSmart.setVelocity(70, percent);
  RightDriveSmart.setMaxTorque(100, percent);
  Drivetrain.driveFor(forward,55,inches);
  Drivetrain.turnToHeading(32, degrees);
  Drivetrain.driveFor(reverse, 16, inches);
  Drivetrain.setDriveVelocity(100, percent);
  Drivetrain.setTimeout(1, seconds);
  Drivetrain.driveFor(forward, 22, inches);
  Drivetrain.setDriveVelocity(35, percent);
  // Phase 2
  Drivetrain.turnToHeading(17,degrees);
  Drivetrain.setDriveVelocity(70, percent);
  Drivetrain.driveFor(reverse,35,inches);
  PneuRight = true;
  PneuLeft = true;
  //LeftDriveSmart.setVelocity(70, percent);
  LeftDriveSmart.spinFor(reverse, 6.3, turns);
  //LeftDriveSmart.setVelocity(70, percent);
  wait(0.5, seconds);
  // Phase 3

  PneuRight = false;
  PneuLeft = false;
  Drivetrain.driveFor(reverse, 28, inches);
  Drivetrain.setTurnVelocity(45, percent);
  Drivetrain.setDriveVelocity(50, percent);
  Drivetrain.turnToHeading(125,degrees);
  Drivetrain.setTimeout(5, seconds);
  Drivetrain.driveFor(forward,57,inches);
  PneuRight = true;
  PneuLeft = true;
  Drivetrain.setTimeout(2, seconds);
  Drivetrain.turnToHeading(100, degrees);
  Drivetrain.driveFor(forward, 2, inches);
}

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    wait(20, msec);
  }
}

int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
