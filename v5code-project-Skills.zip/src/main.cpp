/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    19, 20, 11, 12, 5
// Controller1          controller
// PneuRight            digital_out   A
// PneuLeft             digital_out   B
// Scorpio              motor_group   9, 2
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

void togglePneumatics(void) {
  // Pneumatic toggle function
  if (PneuRight) {
    PneuLeft = false;
    PneuRight = false;
  } else {
    PneuLeft = true;
    PneuRight = true;
  }
}
void runCatapult(){
  distance DistSensor = distance(PORT7);
  while(true)
  {
    if(DistSensor.objectDistance(inches) < 2){
      Scorpio.spinFor(forward, 0.75, turns);
      //numTriballs += 1;
    }
    //Controller1.Screen.clearScreen();
    //Controller1.Screen.setCursor(1, 1);
    //Controller1.Screen.print(numTriballs);
  }
}
void pre_auton(void) {
  // Initializing Robot Configuration
  vexcodeInit();
  
  Scorpio.setVelocity(100, percent);
  Scorpio.setMaxTorque(100, percent);

  Drivetrain.setDriveVelocity(60,percent);
  Drivetrain.setTurnVelocity(10,percent);
  Drivetrain.setStopping(brake);
  Scorpio.setVelocity(100,percent);
  runCatapult();
}

void autonomous(void) {
  // Phase 1
  //float numTriballs = 0;
  Drivetrain.setHeading(330,degrees);
  //runCatapult();
  Controller1.Screen.print(1);
  
  wait(35,seconds);
  // Phase 2
  Drivetrain.driveFor(forward,2,inches);
  Drivetrain.turnFor(right,25,degrees);
  Drivetrain.driveFor(90,inches);
  Drivetrain.setTimeout(5,seconds);
  Drivetrain.turnFor(left,35,degrees);
  Drivetrain.setDriveVelocity(80, percent);
  Drivetrain.driveFor(forward,14,inches);
  Drivetrain.turnFor(left,35,degrees);
  Drivetrain.driveFor(forward,12,inches);
  Drivetrain.driveFor(reverse,12,inches);
  Drivetrain.driveFor(forward,12,inches);
  Drivetrain.driveFor(reverse,4,inches);
  Drivetrain.turnToHeading(180,degrees);
  Drivetrain.setDriveVelocity(60, percent);
  Drivetrain.driveFor(forward,44,inches);
  Drivetrain.turnFor(right,90,degrees);
  Drivetrain.driveFor(forward,20,inches);
  Drivetrain.turnFor(right,90,degrees);
  // Phase 3
  togglePneumatics();
  wait(200,msec);
  Drivetrain.driveFor(forward,28,inches);
  Drivetrain.turnToHeading(0,degrees);
  Drivetrain.driveFor(reverse,6,inches);
  togglePneumatics();
  Drivetrain.driveFor(reverse,28,inches);
  Drivetrain.turnFor(left,90,degrees);
  Drivetrain.driveFor(forward,28,inches);
  Drivetrain.turnFor(right,90,degrees);
  togglePneumatics();
  wait(50,msec);
  Drivetrain.driveFor(forward,22,inches);
  Drivetrain.driveFor(reverse,18,inches);
  togglePneumatics();
}

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    distance DistSensor = distance(PORT7);
    
    if(DistSensor.objectDistance(inches) < 2){
      Scorpio.spinFor(forward, 0.75, turns);
    }

    if (Controller1.ButtonR1.pressing() || Controller1.ButtonR2.pressing()) {
      togglePneumatics();
      if (Controller1.ButtonR1.pressing()) {
        waitUntil(!Controller1.ButtonR1.pressing());
      } else {
        waitUntil(!Controller1.ButtonR2.pressing());
      }
    }
    wait(20, msec);
  }
}

// Main will set up the competition functions and callbacks.
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}