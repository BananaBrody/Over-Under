/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    19, 20, 11, 12, 5
// Controller1          controller
// PneuRight            digital_out   A
// PneuLeft             digital_out   B
// Scorpio              motor_group   9, 2
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

void togglePneumatics(void) {
  // Pneumatic toggle function
  if (PneuRight) {
    PneuLeft = false;
    PneuRight = false;
  } else {
    PneuLeft = true;
    PneuRight = true;
  }
}

void pre_auton(void) {
  // Initializing Robot Configuration
  vexcodeInit();
  Drivetrain.setDriveVelocity(100,percent);
  Drivetrain.setTurnVelocity(100,percent);
  Drivetrain.setStopping(brake);
  Scorpio.setVelocity(40,percent);
}

void autonomous(void) {
  // Phase 1
  Drivetrain.setHeading(330,degrees);
  Scorpio.spin(forward);
  wait(35,seconds);
  Scorpio.stop();
  // Phase 2
  Drivetrain.driveFor(forward,1,inches);
  Drivetrain.turnToHeading(0,degrees);
  Drivetrain.setTurnVelocity(10,percent);
  Drivetrain.setDriveVelocity(70,percent);
  Drivetrain.driveFor(74,inches);
  Drivetrain.setDriveVelocity(100,percent);
  Drivetrain.turnToHeading(315,degrees);
  Drivetrain.driveFor(34,inches);
  Drivetrain.driveFor(reverse,4,inches);
  Drivetrain.turnToHeading(270,degrees);
  Drivetrain.driveFor(forward,8,inches);
  Drivetrain.driveFor(reverse,5,inches);
  Drivetrain.driveFor(forward,5,inches);
  Drivetrain.driveFor(reverse,2,inches);
  Drivetrain.turnToHeading(180,degrees);
  Drivetrain.driveFor(forward,44,inches);
  Drivetrain.turnToHeading(265,degrees);
  Drivetrain.driveFor(forward,20,inches);
  Drivetrain.turnToHeading(0,degrees);
  // Phase 3
  Drivetrain.setTimeout(5,seconds);
  togglePneumatics();
  Drivetrain.driveFor(forward,28,inches);
  Drivetrain.turnToHeading(0,degrees);
  Drivetrain.driveFor(reverse,4,inches);
  togglePneumatics();
  Drivetrain.driveFor(reverse,28,inches);
  Drivetrain.turnToHeading(270,degrees);
  Drivetrain.driveFor(forward,22,inches);
  Drivetrain.turnToHeading(0,degrees);
  togglePneumatics();
  Drivetrain.driveFor(forward,32,inches);
  Drivetrain.driveFor(reverse,10,inches);
}

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    while (Controller1.ButtonL1.pressing() || Controller1.ButtonL2.pressing()) {
      Scorpio.spin(forward);
    }
    if (Controller1.ButtonR1.pressing() || Controller1.ButtonR2.pressing()) {
      togglePneumatics();
      if (Controller1.ButtonR1.pressing()) {
        waitUntil(!Controller1.ButtonR1.pressing());
      } else {
        waitUntil(!Controller1.ButtonR2.pressing());
      }
    }
    wait(20, msec);
  }
}

// Main will set up the competition functions and callbacks.
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}